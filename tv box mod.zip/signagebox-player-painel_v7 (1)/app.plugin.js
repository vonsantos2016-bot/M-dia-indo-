// Ponto de entrada do plugin (Expo procura este arquivo na raiz).
// Apenas exporta a funcao do plugin de forma limpa.
module.exports = require("./plugins/withBootReceiver");
