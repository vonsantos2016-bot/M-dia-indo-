/**
 * Plugin de configuracao do Expo (app.json -> plugins)
 * Sintaxe simples, sem strings complexas: o codigo Kotlin e montado
 * linha a linha em um array, sem nenhum caractere de escape.
 *
 * O que ele faz quando o APK e gerado (prebuild):
 *   1. Garante as permissoes de ligar junto / manter tela acesa.
 *   2. Registra o BootReceiver no AndroidManifest (escuta a TV ligar).
 *   3. Cria o arquivo BootReceiver.kt (abre o player sozinho no boot).
 */

var PERMISSOES = [
  "android.permission.RECEIVE_BOOT_COMPLETED",
  "android.permission.WAKE_LOCK",
  "android.permission.FOREGROUND_SERVICE",
  "android.permission.SYSTEM_ALERT_WINDOW"
];

// Codigo Kotlin montado linha a linha (sem template string, sem escape)
var KOTLIN_LINES = [
  "package com.signagebox.tvplayer",
  "",
  "import android.content.BroadcastReceiver",
  "import android.content.Context",
  "import android.content.Intent",
  "",
  "class BootReceiver : BroadcastReceiver() {",
  "    override fun onReceive(context: Context, intent: Intent) {",
  "        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {",
  "            val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)",
  "            if (launchIntent != null) {",
  "                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)",
  "                context.startActivity(launchIntent)",
  "            }",
  "        }",
  "    }",
  "}",
  ""
];

function withBootReceiver(config) {
  if (!config.android) config.android = {};
  if (!config.android.permissions) config.android.permissions = [];

  // 1. Permissoes: adiciona so se ainda nao existir
  PERMISSOES.forEach(function (permissao) {
    if (config.android.permissions.indexOf(permissao) === -1) {
      config.android.permissions.push(permissao);
    }
  });

  var configPlugins = require("expo/config-plugins");
  var withAndroidManifest = configPlugins.withAndroidManifest;
  var withDangerousMod = configPlugins.withDangerousMod;

  // 2. AndroidManifest: registra o receptor que escuta o boot
  config = withAndroidManifest(config, function (config) {
    var manifest = config.modResults.manifest;
    var app = manifest.application[0];

    if (!manifest["uses-permission"]) {
      manifest["uses-permission"] = [];
    }
    PERMISSOES.forEach(function (permissao) {
      var jaExiste = manifest["uses-permission"].some(function (p) {
        return p.$ && p.$["android:name"] === permissao;
      });
      if (!jaExiste) {
        manifest["uses-permission"].push({ $: { "android:name": permissao } });
      }
    });

    if (!app.receiver) app.receiver = [];

    var jaRegistrado = app.receiver.some(function (r) {
      return r.$ && r.$["android:name"] === ".BootReceiver";
    });

    if (!jaRegistrado) {
      app.receiver.push({
        $: {
          "android:name": ".BootReceiver",
          "android:enabled": "true",
          "android:exported": "true",
          "android:permission": "android.permission.RECEIVE_BOOT_COMPLETED"
        },
        "intent-filter": [
          {
            $: { "android:priority": "999" },
            action: [
              { $: { "android:name": "android.intent.action.BOOT_COMPLETED" } },
              { $: { "android:name": "android.intent.action.QUICKBOOT_POWERON" } },
              { $: { "android:name": "com.htc.intent.action.QUICKBOOT_POWERON" } }
            ],
            category: [
              { $: { "android:name": "android.intent.category.DEFAULT" } }
            ]
          }
        ]
      });
    }

    return config;
  });

  // 3. Escreve o arquivo BootReceiver.kt no projeto Android
  config = withDangerousMod(config, [
    "android",
    function (config) {
      var fs = require("fs");
      var path = require("path");

      var packageName = (config.android && config.android.package) || "com.signagebox.tvplayer";
      var packagePath = packageName.split(".").join("/");

      var dir = path.join(
        config.modRequest.platformProjectRoot,
        "app", "src", "main", "java"
      );
      dir = path.join.apply(path, [dir].concat(packageName.split(".")));

      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      // Ajusta a linha do package para o pacote real do app
      var linhas = KOTLIN_LINES.slice();
      linhas[0] = "package " + packageName;

      fs.writeFileSync(path.join(dir, "BootReceiver.kt"), linhas.join("\n"), "utf8");

      return config;
    }
  ]);

  return config;
}

module.exports = withBootReceiver;
