import * as FileSystem from 'expo-file-system';
import { BackHandler } from 'react-native';
import { DYNAMIC_TYPES, DynamicContentType, LocalMediaItem, LocalPlaylistState, PlaylistItem, SignageManifest } from '../types/manifest';
import { StorageService } from './StorageService';

export const PANEL_MANIFEST_BASE = 'https://supabase.co';
export const SYNC_INTERVAL_MS = 15_000;
const REQUEST_TIMEOUT_MS = 10_000;

export function buildManifestUrl(screenCodeOrUrl: string): string {
  const v = screenCodeOrUrl.trim();
  if (/^https?:\/\//i.test(v)) return v;
  return `${PANEL_MANIFEST_BASE}/${encodeURIComponent(v)}/manifest.json`;
}

export type ScreenStatus = 'idle' | 'syncing' | 'ok' | 'invalid_screen' | 'offline';

export interface SyncState {
  status: ScreenStatus;
  playlist: LocalPlaylistState | null;
  progressText: string;
  progressPercent: number;
  lastHttpStatus: number | null;
}

export class ManifestHttpError extends Error {
  constructor(public status: number) {
    super(`HTTP ${status}`);
  }
}

let state: SyncState = { status: 'idle', playlist: null, progressText: '', progressPercent: 0, lastHttpStatus: null };
const listeners = new Set<(s: SyncState) => void>();

function setState(patch: Partial<SyncState>) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l(state));
}

export interface SyncProgressCallback {
  (status: string, currentItemIndex: number, totalItems: number, progressPercent: number): void;
}

let loopTimer: ReturnType<typeof setTimeout> | null = null;
let loopUrl: string | null = null;
let running = false;
let inFlight = false;

export const SyncService = {
  getState(): SyncState {
    return state;
  },

  subscribe(listener: (s: SyncState) => void): () => void {
    listeners.add(listener);
    listener(state);
    return () => listeners.delete(listener);
  },

  start(screenCodeOrUrl: string) {
    this.stop();
    loopUrl = buildManifestUrl(screenCodeOrUrl);
    running = true;
    const tick = async () => {
      if (!state.playlist) await this.restoreBackupIfOffline();
      if (!running) return;
      const startedAt = Date.now();
      await this.runCycle();
      if (!running) return;
      const wait = Math.max(0, SYNC_INTERVAL_MS - (Date.now() - startedAt));
      loopTimer = setTimeout(tick, wait);
    };
    tick();
  },

  stop() {
    running = false;
    if (loopTimer) clearTimeout(loopTimer);
    loopTimer = null;
  },

  async restoreBackupIfOffline(): Promise<void> {
    const backup = await StorageService.getOfflineBackup<LocalPlaylistState>();
    if (!backup || !Array.isArray(backup.items) || backup.manifestUrl !== loopUrl) return;
    const items: LocalMediaItem[] = [];
    for (const it of backup.items) {
      const isDynamic = DYNAMIC_TYPES.includes(it.type as DynamicContentType);
      if (isDynamic || !it.localUri) { items.push(it); continue; }
      try { if ((await FileSystem.getInfoAsync(it.localUri)).exists) items.push(it); } catch {}
    }
    if (items.length === 0) return;
    setState({ playlist: { ...backup, items }, status: 'ok' });
  },

  async runCycle(): Promise<void> {
    if (inFlight || !loopUrl) return;
    inFlight = true;
    try {
      const manifest = await this.fetchRemoteManifest(loopUrl);
      setState({ lastHttpStatus: 200 });

      if (manifest.remoteCommand === 'QUIT_PLAYER') {
        this.stop();
        setTimeout(() => BackHandler.exitApp(), 300);
        return;
      }

      const current = state.playlist;
      const orientation = manifest.orientation === 'portrait' ? 'portrait' : 'landscape';
      const changed =
        !current ||
        manifest.playlistVersion !== current.playlistVersion ||
        orientation !== (current.orientation ?? 'landscape');

      if (!changed) {
        if (state.status !== 'ok') setState({ status: 'ok' });
        return;
      }

      const playlist = await this.downloadMedia(manifest, loopUrl, (text, _i, _t, pct) =>
        setState({ progressText: text, progressPercent: pct })
      );
      setState({ status: 'ok', playlist });
      await StorageService.saveOfflineBackup(playlist);
    } catch (err) {
      if (err instanceof ManifestHttpError && err.status === 404) {
        setState({ status: 'invalid_screen', lastHttpStatus: 404, playlist: null });
        await StorageService.clearOfflineBackup();
      } else {
        setState({
          status: state.playlist ? 'ok' : 'offline',
          lastHttpStatus: err instanceof ManifestHttpError ? err.status : null,
        });
      }
    } finally {
      inFlight = false;
    }
  },

  async fetchRemoteManifest(manifestUrl: string): Promise<SignageManifest> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const sep = manifestUrl.includes('?') ? '&' : '?';
      const response = await fetch(`${manifestUrl}${sep}_t=${Date.now()}`, {
        signal: controller.signal,
        headers: { Accept: 'application/json', 'Cache-Control': 'no-cache' },
      });
      if (response.status !== 200) throw new ManifestHttpError(response.status);

      const data = await response.json();
      if (!data || typeof data.playlistVersion !== 'number' || !Array.isArray(data.items)) {
        throw new Error('Manifesto malformado');
      }
      data.items = data.items
        .filter((raw: any) => raw && typeof raw === 'object')
        .map((raw: any, i: number) => ({
          ...raw,
          id: String(raw.id ?? `item-${i}`),
          url: raw.url ?? raw.source_url ?? '',
          widgetType: raw.widgetType ?? raw.widget_type ?? '',
          title: raw.title ?? '',
          duration: Math.max(1, Number(raw.duration ?? raw.duration_seconds) || 0) || undefined,
        }))
        .filter((it: PlaylistItem) => {
          const isDynamic = DYNAMIC_TYPES.includes(it.type as DynamicContentType);
          return isDynamic || !!it.url;
        });
      return data as SignageManifest;
    } finally {
      clearTimeout(timeoutId);
    }
  },

  generateLocalFilename(item: PlaylistItem): string {
    const sanitizedId = item.id.replace(/[^a-zA-Z0-9_-]/g, '_');
    const path = item.url.split('?')[0];
    const extension = path.includes('.') ? path.split('.').pop()?.toLowerCase() : null;
    const defaultExt = item.type === 'video' ? 'mp4' : 'jpg';
    const ext = extension && ['mp4', 'mkv', 'webm', 'mov', 'jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'].includes(extension)
      ? extension
      : defaultExt;
    return `media_${sanitizedId}.${ext}`;
  },

  async downloadMedia(
    manifest: SignageManifest,
    manifestUrl: string,
    onProgress?: SyncProgressCallback
  ): Promise<LocalPlaylistState> {
    await StorageService.ensureMediaDirectory();
    const mediaDir = StorageService.getMediaDirectory();
    const total = manifest.items.length;
    const items: LocalMediaItem[] = [];

    onProgress?.(`Sincronizando versão (${manifest.playlistVersion})...`, 0, total, 10);

    for (let i = 0; i < total; i++) {
      const item = manifest.items[i];
      const pct = Math.round(((i + 1) / Math.max(1, total)) * 90) + 10;
      const isDynamic = DYNAMIC_TYPES.includes(item.type as DynamicContentType);

      if (isDynamic) {
        onProgress?.(`Configurando widget ${item.widgetType || item.type}...`, i + 1, total, pct);
        items.push({ ...item, localUri: '' });
        continue;
      }

      const filename = this.generateLocalFilename(item);
      const localUri = `${mediaDir}${filename}`;
      onProgress?.(`Baixando mídia ${i + 1} de ${total}...`, i + 1, total, pct);

      try {
        const info = await FileSystem.getInfoAsync(localUri);
        if (!info.exists) {
          await FileSystem.downloadAsync(item.url, localUri);
        }
        items.push({ ...item, localUri, downloadedAt: Date.now() });
      } catch (err) {
        console.warn(`[SyncService] Erro ao baixar ${item.url}:`, err);
      }
    }

    return {
      playlistVersion: manifest.playlistVersion,
      manifestUrl,
      orientation: manifest.orientation === 'portrait' ? 'portrait' : 'landscape',
      playbackMode: manifest.playbackMode,
      items,
      lastSyncedAt: Date.now(),
    };
  },
};
