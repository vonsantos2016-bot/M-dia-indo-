import AsyncStorage from '@react-native-async-storage/async-storage';
import { LocalMediaItem } from '../types/manifest';

const CACHE_PREFIX = '@signage_dynamic_cache:';

export interface DynamicResult {
  content: any;
  fetchedAt: string;
  fromCache: boolean;
}

export const playlistEngine = {
  processPlaybackMode(items: LocalMediaItem[], mode?: 'sequential' | 'random'): LocalMediaItem[] {
    if (mode !== 'random') return [...items];
    const q = [...items];
    for (let i = q.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [q[i], q[j]] = [q[j], q[i]];
    }
    return q;
  },

  async fetchDynamicContent(item: LocalMediaItem): Promise<DynamicResult | null> {
    const key = `${CACHE_PREFIX}${item.id}`;

    // 1. Se o painel/Supabase já mandou widgetData pronto no manifesto, salva no cache e usa na hora
    if (item.widgetData !== undefined && item.widgetData !== null) {
      const fetchedAt = new Date().toISOString();
      await AsyncStorage.setItem(key, JSON.stringify({ content: item.widgetData, fetchedAt })).catch(() => {});
      return { content: item.widgetData, fetchedAt, fromCache: false };
    }

    // 2. Se não tem URL externa, tenta ler do cache offline
    if (!item.url) {
      try {
        const raw = await AsyncStorage.getItem(key);
        if (raw) return { ...JSON.parse(raw), fromCache: true };
      } catch {}
      return null;
    }

    // 3. Busca direta por URL (RSS / JSON / API externa) com fallback offline
    const controller = new AbortController();
    const t = setTimeout(() => controller.abort(), 10000);
    try {
      const res = await fetch(item.url, { signal: controller.signal, headers: { 'Cache-Control': 'no-cache' } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const content = item.type === 'rss_feed' ? await res.text() : await res.json();
      const fetchedAt = new Date().toISOString();
      await AsyncStorage.setItem(key, JSON.stringify({ content, fetchedAt }));
      return { content, fetchedAt, fromCache: false };
    } catch (err) {
      console.warn(`[PlaylistEngine] Falha ao buscar ${item.type} (${item.id}), usando cache:`, err);
      try {
        const raw = await AsyncStorage.getItem(key);
        if (raw) return { ...JSON.parse(raw), fromCache: true };
      } catch {}
      return null;
    } finally {
      clearTimeout(t);
    }
  },
};

