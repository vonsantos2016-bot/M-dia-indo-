import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';

const STORAGE_KEY_MANIFEST_URL = '@signage_manifest_url';
const STORAGE_KEY_BACKUP = '@signage_offline_backup';
const MEDIA_DIRECTORY = `${FileSystem.documentDirectory}signage_media/`;

export const StorageService = {
  async saveManifestUrl(url: string): Promise<void> {
    await AsyncStorage.setItem(STORAGE_KEY_MANIFEST_URL, url.trim());
  },

  async getManifestUrl(): Promise<string | null> {
    return await AsyncStorage.getItem(STORAGE_KEY_MANIFEST_URL);
  },

  async clearManifestUrl(): Promise<void> {
    await AsyncStorage.removeItem(STORAGE_KEY_MANIFEST_URL);
  },

  async ensureMediaDirectory(): Promise<void> {
    const dirInfo = await FileSystem.getInfoAsync(MEDIA_DIRECTORY);
    if (!dirInfo.exists) {
      await FileSystem.makeDirectoryAsync(MEDIA_DIRECTORY, { intermediates: true });
    }
  },

  getMediaDirectory(): string {
    return MEDIA_DIRECTORY;
  },

  /** Cópia de segurança usada SOMENTE quando a TV Box liga sem internet. */
  async saveOfflineBackup(state: unknown): Promise<void> {
    try { await AsyncStorage.setItem(STORAGE_KEY_BACKUP, JSON.stringify(state)); } catch {}
  },

  async getOfflineBackup<T>(): Promise<T | null> {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY_BACKUP);
      return raw ? (JSON.parse(raw) as T) : null;
    } catch { return null; }
  },

  async clearOfflineBackup(): Promise<void> {
    try { await AsyncStorage.removeItem(STORAGE_KEY_BACKUP); } catch {}
  },

  async cleanupObsoleteMedia(activeLocalUris: string[]): Promise<void> {
    try {
      await this.ensureMediaDirectory();
      const files = await FileSystem.readDirectoryAsync(MEDIA_DIRECTORY);
      const activeFilenames = activeLocalUris.map(uri => uri.split('/').pop() || '');

      for (const file of files) {
        if (!activeFilenames.includes(file)) {
          const filePath = `${MEDIA_DIRECTORY}${file}`;
          await FileSystem.deleteAsync(filePath, { idempotent: true });
        }
      }
    } catch (error) {
      console.warn('[StorageService] Erro ao limpar mídias obsoletas:', error);
    }
  }
};