import React, { useState, useEffect, useRef, useCallback } from 'react';
import { View, Image, StyleSheet, StatusBar } from 'react-native';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { useKeepAwake } from 'expo-keep-awake';
import { LocalMediaItem, DYNAMIC_TYPES, DynamicContentType } from '../types/manifest';
import { playlistEngine, DynamicResult } from '../services/PlaylistEngine';
import { WeatherDisplay } from './dynamic/WeatherDisplay';
import { RssDisplay } from './dynamic/RssDisplay';
import { MegaSenaDisplay } from './dynamic/MegaSenaDisplay';
import { WidgetRenderer } from './dynamic/WidgetRenderer';

interface SignagePlayerProps {
  items: LocalMediaItem[];
  onLoopCompleted?: (loopCount: number) => void;
  playbackMode?: 'sequential' | 'random';
}

export const SignagePlayer: React.FC<SignagePlayerProps> = ({ items: sourceItems, onLoopCompleted, playbackMode }) => {
  useKeepAwake();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [items, setItems] = useState<LocalMediaItem[]>(() => playlistEngine.processPlaybackMode(sourceItems, playbackMode));
  const [dynamic, setDynamic] = useState<DynamicResult | null>(null);

  useEffect(() => {
    setItems(playlistEngine.processPlaybackMode(sourceItems, playbackMode));
    setCurrentIndex(0);
  }, [sourceItems, playbackMode]);

  const loopCountRef = useRef(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const watchdogTimerRef = useRef<NodeJS.Timeout | null>(null);
  const videoRef = useRef<Video | null>(null);

  const currentItem = items[currentIndex];

  const advanceToNext = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (watchdogTimerRef.current) {
      clearTimeout(watchdogTimerRef.current);
      watchdogTimerRef.current = null;
    }

    if (videoRef.current) {
      videoRef.current.unloadAsync().catch(() => {});
    }

    setCurrentIndex((prev) => {
      const nextIndex = (prev + 1) % items.length;
      if (nextIndex === 0) {
        loopCountRef.current += 1;
        if (playbackMode === 'random') setItems(playlistEngine.processPlaybackMode(sourceItems, playbackMode));
        onLoopCompleted?.(loopCountRef.current);
      }
      return nextIndex;
    });
  }, [items.length, onLoopCompleted, playbackMode, sourceItems]);

  useEffect(() => {
    if (!currentItem) return;

    setDynamic(null);
    const isDynamic = DYNAMIC_TYPES.includes(currentItem.type as DynamicContentType);
    let cancelled = false;

    if (isDynamic) {
      playlistEngine.fetchDynamicContent(currentItem).then((res) => {
        if (!cancelled) setDynamic(res);
      });
    }

    if (currentItem.type === 'image' || isDynamic) {
      const durationSeconds = currentItem.duration && currentItem.duration > 0 ? currentItem.duration : 12;
      timerRef.current = setTimeout(() => {
        advanceToNext();
      }, durationSeconds * 1000);
    } else if (currentItem.type === 'video') {
      const maxVideoTimeout = (currentItem.duration && currentItem.duration > 0 ? currentItem.duration + 5 : 45) * 1000;
      watchdogTimerRef.current = setTimeout(() => {
        advanceToNext();
      }, maxVideoTimeout);
    }

    return () => {
      cancelled = true;
      if (timerRef.current) clearTimeout(timerRef.current);
      if (watchdogTimerRef.current) clearTimeout(watchdogTimerRef.current);
    };
  }, [currentIndex, currentItem, advanceToNext]);

  const handleVideoStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded) {
      if (status.error) {
        advanceToNext();
      }
      return;
    }

    if (status.didJustFinish) {
      advanceToNext();
    }
  };

  if (!currentItem) {
    return <View style={styles.blackBackground} />;
  }

  return (
    <View style={styles.container} pointerEvents="none">
      <StatusBar hidden={true} translucent={true} />

      {DYNAMIC_TYPES.includes(currentItem.type as DynamicContentType) ? (
        <View style={styles.dynamicContainer}>
          {dynamic && currentItem.type === 'widget' && (
            <WidgetRenderer
              widgetType={currentItem.widgetType || currentItem.widget_type || 'saude'}
              data={dynamic.content}
              timestamp={dynamic.fetchedAt}
              fromCache={dynamic.fromCache}
            />
          )}
          {dynamic && currentItem.type === 'weather_api' && (
            <WeatherDisplay apiData={dynamic.content} timestamp={dynamic.fetchedAt} fromCache={dynamic.fromCache} />
          )}
          {dynamic && currentItem.type === 'rss_feed' && (
            <RssDisplay xmlData={dynamic.content} maxItems={currentItem.maxItems} timestamp={dynamic.fetchedAt} fromCache={dynamic.fromCache} />
          )}
          {dynamic && currentItem.type === 'lottery_json' && (
            <MegaSenaDisplay apiData={dynamic.content} timestamp={dynamic.fetchedAt} fromCache={dynamic.fromCache} />
          )}
        </View>
      ) : currentItem.type === 'video' ? (
        <Video
          ref={videoRef}
          key={`tv-video-${currentItem.id}-${currentIndex}`}
          source={{ uri: currentItem.localUri }}
          style={styles.fullscreenMedia}
          resizeMode={ResizeMode.COVER}
          shouldPlay={true}
          isLooping={false}
          isMuted={false}
          useNativeControls={false}
          onPlaybackStatusUpdate={handleVideoStatusUpdate}
          onError={() => {
            advanceToNext();
          }}
        />
      ) : (
        <Image
          key={`tv-image-${currentItem.id}-${currentIndex}`}
          source={{ uri: currentItem.localUri }}
          style={styles.fullscreenMedia}
          resizeMode="cover"
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: '100%',
    height: '100%',
    backgroundColor: '#000000',
    overflow: 'hidden',
  },
  dynamicContainer: {
    flex: 1,
    backgroundColor: '#09090b',
    alignItems: 'center',
    justifyContent: 'center',
  },
  blackBackground: {
    flex: 1,
    backgroundColor: '#000000',
  },
  fullscreenMedia: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
});
