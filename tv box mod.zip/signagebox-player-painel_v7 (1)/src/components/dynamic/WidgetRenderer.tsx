import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { UpdatedFooter } from './Footer';

interface WidgetRendererProps {
  widgetType: string;
  data: any;
  timestamp: string | null;
  fromCache?: boolean;
}

export const WidgetRenderer: React.FC<WidgetRendererProps> = ({ widgetType, data, timestamp, fromCache }) => {
  const type = (widgetType || '').toLowerCase();
  const payload = data ?? {};

  // 1. ESPORTES / BRASILEIRÃO
  if (type.includes('esporte') || type.includes('futebol') || type.includes('brasileirao')) {
    const tabela = Array.isArray(payload.tabela) ? payload.tabela : Array.isArray(payload.standings) ? payload.standings : [];
    const jogos = Array.isArray(payload.jogos) ? payload.jogos : Array.isArray(payload.matches) ? payload.matches : [];
    const manchetes = Array.isArray(payload.manchetes) ? payload.manchetes : [];

    return (
      <View style={styles.screen}>
        <View style={styles.headerRow}>
          <Text style={styles.badgeGreen}>BRASILEIRÃO SÉRIE A</Text>
          <Text style={styles.headerTitle}>Classificação & Rodada</Text>
        </View>

        <View style={styles.twoColumns}>
          <View style={styles.colLeft}>
            <Text style={styles.sectionTitle}>TABELA (TOP 8)</Text>
            {tabela.slice(0, 8).map((t: any, idx: number) => (
              <View key={idx} style={styles.tableRow}>
                <Text style={styles.posText}>{t.posicao ?? t.pos ?? idx + 1}º</Text>
                <Text style={styles.teamText} numberOfLines={1}>{t.time ?? t.team ?? t.nome ?? ''}</Text>
                <Text style={styles.ptsText}>{t.pontos ?? t.pts ?? 0} pts</Text>
              </View>
            ))}
            {tabela.length === 0 && <Text style={styles.emptyText}>Carregando tabela...</Text>}
          </View>

          <View style={styles.colRight}>
            <Text style={styles.sectionTitle}>{jogos.length > 0 ? 'JOGOS DA RODADA' : 'ÚLTIMAS DO GE'}</Text>
            {jogos.length > 0
              ? jogos.slice(0, 5).map((j: any, idx: number) => (
                  <View key={idx} style={styles.matchCard}>
                    <Text style={styles.matchText}>
                      {j.mandante ?? j.home ?? ''} {j.placarMandante ?? j.homeScore ?? ''} x {j.placarVisitante ?? j.awayScore ?? ''} {j.visitante ?? j.away ?? ''}
                    </Text>
                    {j.status ? <Text style={styles.matchSub}>{j.status}</Text> : null}
                  </View>
                ))
              : manchetes.slice(0, 4).map((m: any, idx: number) => (
                  <Text key={idx} style={styles.newsBullet} numberOfLines={2}>• {typeof m === 'string' ? m : m.titulo ?? m.title}</Text>
                ))}
          </View>
        </View>
        <UpdatedFooter timestamp={timestamp} fromCache={fromCache} />
      </View>
    );
  }

  // 2. NOTÍCIAS (G1 / RSS)
  if (type.includes('noticia') || type.includes('news')) {
    const lista = Array.isArray(payload.noticias) ? payload.noticias : Array.isArray(payload.items) ? payload.items : Array.isArray(payload) ? payload : [];
    const destaque = lista[0];

    return (
      <View style={styles.screen}>
        <View style={styles.headerRow}>
          <Text style={styles.badgeRed}>ÚLTIMAS NOTÍCIAS</Text>
          <Text style={styles.headerTitle}>Destaques do Dia</Text>
        </View>

        {destaque && (
          <View style={styles.highlightBox}>
            {destaque.imagem || destaque.image ? (
              <Image source={{ uri: destaque.imagem || destaque.image }} style={styles.newsThumb} />
            ) : null}
            <View style={{ flex: 1 }}>
              <Text style={styles.highlightTitle} numberOfLines={3}>{destaque.titulo ?? destaque.title ?? ''}</Text>
              {destaque.resumo || destaque.description ? (
                <Text style={styles.highlightSub} numberOfLines={2}>{destaque.resumo ?? destaque.description}</Text>
              ) : null}
            </View>
          </View>
        )}

        <View style={{ width: '100%', marginTop: 16 }}>
          {lista.slice(1, 5).map((n: any, idx: number) => (
            <Text key={idx} style={styles.newsLine} numberOfLines={1}>
              • {typeof n === 'string' ? n : n.titulo ?? n.title ?? ''}
            </Text>
          ))}
        </View>
        <UpdatedFooter timestamp={timestamp} fromCache={fromCache} />
      </View>
    );
  }

  // 3. CLIMA / PREVISÃO DO TEMPO
  if (type.includes('clima') || type.includes('weather')) {
    const temp = payload.temperatura ?? payload.temp ?? payload.current?.temperature_2m ?? '--';
    const max = payload.maxima ?? payload.max ?? '--';
    const min = payload.minima ?? payload.min ?? '--';
    const cidade = payload.cidade ?? payload.city ?? 'Previsão Local';
    const desc = payload.descricao ?? payload.description ?? 'Tempo Atual';

    return (
      <View style={styles.centerCard}>
        <Text style={styles.badgeAmber}>PREVISÃO DO TEMPO</Text>
        <Text style={styles.cityBig}>{cidade}</Text>
        <Text style={styles.tempGiant}>{Math.round(Number(temp)) || temp}°C</Text>
        <Text style={styles.weatherDesc}>{desc}</Text>
        <Text style={styles.minMax}>Mínima: {min}°C   |   Máxima: {max}°C</Text>
        <UpdatedFooter timestamp={timestamp} fromCache={fromCache} />
      </View>
    );
  }

  // 4. MOEDAS / ECONOMIA (DÓLAR, EURO, BITCOIN)
  if (type.includes('moeda') || type.includes('economia') || type.includes('dolar')) {
    const usd = payload.USDBRL ?? payload.dolar ?? {};
    const eur = payload.EURBRL ?? payload.euro ?? {};
    const btc = payload.BTCBRL ?? payload.bitcoin ?? {};

    const renderCoin = (nome: string, obj: any) => {
      const valor = Number(obj.bid ?? obj.valor ?? 0);
      const varPct = Number(obj.pctChange ?? obj.variacao ?? 0);
      const isUp = varPct >= 0;
      return (
        <View style={styles.coinCard}>
          <Text style={styles.coinName}>{nome}</Text>
          <Text style={styles.coinValue}>
            {valor > 0 ? valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : '--'}
          </Text>
          <Text style={[styles.coinVar, { color: isUp ? '#4ade80' : '#f87171' }]}>
            {isUp ? '▲' : '▼'} {Math.abs(varPct).toFixed(2)}%
          </Text>
        </View>
      );
    };

    return (
      <View style={styles.screen}>
        <View style={styles.headerRow}>
          <Text style={styles.badgeAmber}>COTAÇÕES & ECONOMIA</Text>
          <Text style={styles.headerTitle}>Mercado Financeiro</Text>
        </View>
        <View style={styles.coinsRow}>
          {renderCoin('DÓLAR (USD)', usd)}
          {renderCoin('EURO (EUR)', eur)}
          {renderCoin('BITCOIN (BTC)', btc)}
        </View>
        <UpdatedFooter timestamp={timestamp} fromCache={fromCache} />
      </View>
    );
  }

  // 5. LOTERIAS / MEGA-SENA
  if (type.includes('loteria') || type.includes('mega')) {
    const dezenas: string[] = (payload.dezenas ?? payload.listaDezenas ?? []).map(String);
    return (
      <View style={styles.megaCard}>
        <Text style={styles.megaTitle}>MEGA-SENA</Text>
        <Text style={styles.megaSub}>Concurso {payload.concurso ?? payload.numero ?? ''} {payload.data ? `· ${payload.data}` : ''}</Text>
        <View style={styles.ballsRow}>
          {dezenas.map((n, i) => (
            <View key={i} style={styles.ball}><Text style={styles.ballText}>{n.padStart(2, '0')}</Text></View>
          ))}
        </View>
        {payload.acumulou !== undefined && (
          <Text style={styles.megaAcc}>{payload.acumulou ? 'ACUMULOU!' : 'TEVE GANHADOR!'}</Text>
        )}
        <UpdatedFooter timestamp={timestamp} fromCache={fromCache} />
      </View>
    );
  }

  // 6. DICAS DE SAÚDE & BEM-ESTAR (Padrão)
  const dicas = Array.isArray(payload.dicas) ? payload.dicas : Array.isArray(payload) ? payload : [payload];
  const dicaAtual = dicas[0] ?? {};

  return (
    <View style={styles.healthCard}>
      <Text style={styles.badgeTeal}>{dicaAtual.categoria ?? 'SAÚDE & BEM-ESTAR'}</Text>
      <Text style={styles.healthTitle}>{dicaAtual.titulo ?? 'Dica de Qualidade de Vida'}</Text>
      <Text style={styles.healthBody}>
        {dicaAtual.texto ?? 'Mantenha-se hidratado ao longo do dia e faça pequenas pausas para alongar o corpo.'}
      </Text>
      <UpdatedFooter timestamp={timestamp} fromCache={fromCache} />
    </View>
  );
};

const styles = StyleSheet.create({
  screen: { width: '92%', height: '88%', backgroundColor: '#18181b', borderRadius: 24, padding: 36, justifyContent: 'space-between', borderWidth: 1, borderColor: '#27272a' },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 16, marginBottom: 16 },
  headerTitle: { color: '#ffffff', fontSize: 30, fontWeight: '800' },
  badgeGreen: { backgroundColor: '#16a34a', color: '#fff', fontWeight: '900', fontSize: 16, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 8 },
  badgeRed: { backgroundColor: '#dc2626', color: '#fff', fontWeight: '900', fontSize: 16, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 8 },
  badgeAmber: { backgroundColor: '#f59e0b', color: '#09090b', fontWeight: '900', fontSize: 16, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 8 },
  badgeTeal: { backgroundColor: '#0d9488', color: '#fff', fontWeight: '900', fontSize: 18, paddingHorizontal: 18, paddingVertical: 8, borderRadius: 10, marginBottom: 20 },
  twoColumns: { flex: 1, flexDirection: 'row', gap: 28 },
  colLeft: { flex: 1.1, backgroundColor: '#09090b', borderRadius: 16, padding: 20 },
  colRight: { flex: 1, backgroundColor: '#09090b', borderRadius: 16, padding: 20 },
  sectionTitle: { color: '#fbbf24', fontSize: 18, fontWeight: '800', marginBottom: 12 },
  tableRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: '#27272a' },
  posText: { color: '#a1a1aa', fontSize: 20, fontWeight: '700', width: 42 },

