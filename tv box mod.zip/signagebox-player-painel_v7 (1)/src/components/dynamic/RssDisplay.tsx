import React, { useMemo } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { UpdatedFooter } from './Footer';

const decode = (s: string) =>
  s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/<[^>]+>/g, '')
   .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
   .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").trim();

/** Leitor leve de RSS 2.0 / Atom sem bibliotecas extras. */
export function parseRss(xml: string): { channel: string; titles: string[] } {
  const channel = decode(xml.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? 'Notícias');
  const blocks = xml.match(/<(item|entry)[\s>][\s\S]*?<\/\1>/gi) ?? [];
  const titles = blocks
    .map((b) => decode(b.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? ''))
    .filter(Boolean);
  return { channel, titles };
}

export const RssDisplay: React.FC<{ xmlData: string; maxItems?: number; timestamp: string | null; fromCache?: boolean }> = ({ xmlData, maxItems = 5, timestamp, fromCache }) => {
  const { channel, titles } = useMemo(() => parseRss(String(xmlData ?? '')), [xmlData]);
  return (
    <View style={styles.card}>
      <Text style={styles.channel}>{channel}</Text>
      {titles.slice(0, maxItems).map((t, i) => (
        <Text key={i} style={styles.item} numberOfLines={2}>• {t}</Text>
      ))}
      {titles.length === 0 && <Text style={styles.item}>Nenhuma notícia disponível.</Text>}
      <UpdatedFooter timestamp={timestamp} fromCache={fromCache} />
    </View>
  );
};

const styles = StyleSheet.create({
  card: { width: '90%', padding: 40, backgroundColor: '#18181b', borderRadius: 20 },
  channel: { color: '#f59e0b', fontSize: 30, fontWeight: 'bold', marginBottom: 20 },
  item: { color: '#fff', fontSize: 24, marginBottom: 14 },
});
