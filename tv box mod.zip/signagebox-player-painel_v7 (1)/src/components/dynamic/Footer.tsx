import React from 'react';
import { Text, StyleSheet } from 'react-native';

export const UpdatedFooter: React.FC<{ timestamp: string | null; fromCache?: boolean }> = ({ timestamp, fromCache }) =>
  timestamp ? (
    <Text style={styles.footer}>
      {fromCache ? 'Modo offline · ' : ''}Atualizado em: {new Date(timestamp).toLocaleString('pt-BR')}
    </Text>
  ) : null;

const styles = StyleSheet.create({ footer: { color: '#71717a', fontSize: 14, marginTop: 24 } });
