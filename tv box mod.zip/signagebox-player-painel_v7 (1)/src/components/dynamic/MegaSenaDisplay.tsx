import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { UpdatedFooter } from './Footer';

/** Compatível com loteriascaixa-api.herokuapp.com e com a API oficial da Caixa. */
export const MegaSenaDisplay: React.FC<{ apiData: any; timestamp: string | null; fromCache?: boolean }> = ({ apiData, timestamp, fromCache }) => {
  const d = Array.isArray(apiData) ? apiData[0] : apiData ?? {};
  const dezenas: string[] = (d.dezenas ?? d.listaDezenas ?? d.dezenasSorteadasOrdemSorteio ?? []).map(String);
  const concurso = d.concurso ?? d.numero ?? '';
  const data = d.data ?? d.dataApuracao ?? '';
  const acumulou = d.acumulou ?? d.acumulado;
  const proximo = d.valorEstimadoProximoConcurso;
  return (
    <View style={styles.card}>
      <Text style={styles.title}>MEGA-SENA</Text>
      <Text style={styles.sub}>Concurso {concurso} {data ? `· ${data}` : ''}</Text>
      <View style={styles.row}>
        {dezenas.map((n, i) => (
          <View key={i} style={styles.ball}><Text style={styles.ballText}>{n.padStart(2, '0')}</Text></View>
        ))}
      </View>
      {acumulou !== undefined && <Text style={styles.acc}>{acumulou ? 'ACUMULOU!' : 'Teve ganhador'}</Text>}
      {typeof proximo === 'number' && (
        <Text style={styles.sub}>Próximo prêmio estimado: {proximo.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</Text>
      )}
      <UpdatedFooter timestamp={timestamp} fromCache={fromCache} />
    </View>
  );
};

const styles = StyleSheet.create({
  card: { padding: 48, backgroundColor: '#064e3b', borderRadius: 20, alignItems: 'center' },
  title: { color: '#fff', fontSize: 40, fontWeight: 'bold', letterSpacing: 2 },
  sub: { color: '#d1fae5', fontSize: 22, marginTop: 10 },
  row: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', marginTop: 28 },
  ball: { width: 84, height: 84, borderRadius: 42, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', margin: 8 },
  ballText: { color: '#065f46', fontSize: 34, fontWeight: 'bold' },
  acc: { color: '#fbbf24', fontSize: 30, fontWeight: 'bold', marginTop: 24 },
});
