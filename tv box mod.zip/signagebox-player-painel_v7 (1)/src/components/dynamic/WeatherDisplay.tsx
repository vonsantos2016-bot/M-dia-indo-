import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { UpdatedFooter } from './Footer';

/** Compatível com HG Brasil ({ results: { city, temp, description } }) e formatos simples. */
export const WeatherDisplay: React.FC<{ apiData: any; timestamp: string | null; fromCache?: boolean }> = ({ apiData, timestamp, fromCache }) => {
  const r = apiData?.results ?? apiData ?? {};
  return (
    <View style={styles.card}>
      <Text style={styles.title}>Previsão do Tempo</Text>
      <Text style={styles.city}>{r.city ?? r.city_name ?? r.name ?? ''}</Text>
      <Text style={styles.temp}>{r.temp ?? r.temperature ?? r.main?.temp ?? '--'}°C</Text>
      <Text style={styles.desc}>{r.description ?? r.weather?.[0]?.description ?? ''}</Text>
      <UpdatedFooter timestamp={timestamp} fromCache={fromCache} />
    </View>
  );
};

const styles = StyleSheet.create({
  card: { padding: 48, backgroundColor: '#18181b', borderRadius: 20, alignItems: 'center', minWidth: '50%' },
  title: { color: '#fff', fontSize: 32, fontWeight: 'bold' },
  city: { color: '#a1a1aa', fontSize: 24, marginTop: 12 },
  temp: { color: '#f59e0b', fontSize: 96, fontWeight: 'bold' },
  desc: { color: '#fff', fontSize: 28 },
});
