import React, { useState } from 'react';
const PANEL_MANIFEST_BASE = 'https://sbbsivqsxculsmjbiaid.supabase.co/functions/v1/manifest/screens';
// Painel: https://digital-signage-admi-8c6f.bolt.host/
const buildManifestUrl = (input: string) =>
  /^https?:\/\//i.test(input) ? input : `${PANEL_MANIFEST_BASE}/${input}/manifest.json`;

import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';

interface SetupScreenProps {
  onSaveUrl: (url: string) => Promise<void>;
  initialUrl?: string;
}

export const SetupScreen: React.FC<SetupScreenProps> = ({ onSaveUrl, initialUrl = '' }) => {
  const [url, setUrl] = useState(initialUrl);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [inputFocused, setInputFocused] = useState(false);
  const [buttonFocused, setButtonFocused] = useState(false);

  const handleSubmit = async () => {
    const cleanUrl = url.trim();
    if (!cleanUrl) {
      setErrorMsg('Digite o ID da tela cadastrada no painel.');
      return;
    }

    setErrorMsg(null);
    setLoading(true);

    try {
      await onSaveUrl(buildManifestUrl(cleanUrl));
    } catch (err: any) {
      setErrorMsg(err.message || 'Falha ao salvar manifesto.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>SISTEMA DE MÍDIA INDOOR - MODO TV BOX</Text>
        </View>

        <Text style={styles.title}>Configuração Inicial</Text>
        <Text style={styles.subtitle}>
          Use o controle remoto (D-Pad) para digitar o ID da tela (copiado no painel) ou colar o link completo do manifesto.
        </Text>

        <View style={styles.inputContainer}>
          <TextInput
            style={[styles.input, inputFocused && styles.inputFocused]}
            placeholder="ID da tela (ex: 3f2a...)"
            placeholderTextColor="#71717a"
            value={url}
            onChangeText={(text: string) => setUrl(text)}
            onFocus={() => setInputFocused(true)}
            onBlur={() => setInputFocused(false)}
            hasTVPreferredFocus={true}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="default"
            returnKeyType="done"
            onSubmitEditing={handleSubmit}
          />
        </View>

        {errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}

        <TouchableOpacity
          style={[styles.button, buttonFocused && styles.buttonFocused, loading && styles.buttonDisabled]}
          onPress={handleSubmit}
          onFocus={() => setButtonFocused(true)}
          onBlur={() => setButtonFocused(false)}
          activeOpacity={0.8}
        >
          {loading ? (
            <ActivityIndicator color="#000000" />
          ) : (
            <Text style={styles.buttonText}>
              {buttonFocused ? '▶ CONECTAR & INICIAR' : 'Conectar & Sincronizar'}
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#09090b', alignItems: 'center', justifyContent: 'center', padding: 24 },
  card: { width: '90%', maxWidth: 680, backgroundColor: '#18181b', borderRadius: 20, padding: 32, borderWidth: 1, borderColor: '#27272a' },
  badge: { alignSelf: 'flex-start', backgroundColor: '#f59e0b20', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, borderWidth: 1, borderColor: '#f59e0b40', marginBottom: 16 },
  badgeText: { color: '#fbbf24', fontSize: 12, fontWeight: '800' },
  title: { fontSize: 28, fontWeight: 'bold', color: '#ffffff', marginBottom: 8 },
  subtitle: { fontSize: 14, color: '#a1a1aa', marginBottom: 20 },
  inputContainer: { marginBottom: 16 },
  input: { backgroundColor: '#09090b', borderWidth: 2, borderColor: '#3f3f46', borderRadius: 12, color: '#ffffff', fontSize: 16, padding: 14 },
  inputFocused: { borderColor: '#f59e0b', backgroundColor: '#18181b' },
  errorText: { color: '#f87171', fontSize: 14, marginBottom: 16 },
  button: { backgroundColor: '#f59e0b', borderRadius: 12, paddingVertical: 16, alignItems: 'center', borderWidth: 2, borderColor: 'transparent' },
  buttonFocused: { borderColor: '#ffffff', backgroundColor: '#fbbf24', transform: [{ scale: 1.02 }] },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: '#000000', fontSize: 16, fontWeight: '800' },
});