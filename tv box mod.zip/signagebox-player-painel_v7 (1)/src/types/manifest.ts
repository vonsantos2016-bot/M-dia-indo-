export type DisplayOrientation = 'landscape' | 'portrait';

export type StaticMediaType = 'video' | 'image';
export type DynamicContentType = 'rss_feed' | 'weather_api' | 'lottery_json' | 'widget';
export type PlaylistItemType = StaticMediaType | DynamicContentType;
export const DYNAMIC_TYPES: DynamicContentType[] = ['rss_feed', 'weather_api', 'lottery_json', 'widget'];

export interface PlaylistItem {
  id: string;
  url: string;
  source_url?: string;
  type: PlaylistItemType;
  widgetType?: string;
  widget_type?: string;
  widgetData?: any;
  title?: string;
  duration?: number;
  duration_seconds?: number;
  maxItems?: number;
  [key: string]: unknown;
}

export interface LocalMediaItem extends PlaylistItem {
  localUri: string;
  downloadedAt?: number;
  fileSize?: number;
}

export interface SignageManifest {
  playlistVersion: number;
  orientation?: DisplayOrientation;
  items: PlaylistItem[];
  remoteCommand?: string | null;
  playbackMode?: 'sequential' | 'random';
  [key: string]: unknown;
}

export interface LocalPlaylistState {
  playlistVersion: number;
  manifestUrl?: string;
  orientation?: DisplayOrientation;
  playbackMode?: 'sequential' | 'random';
  items: LocalMediaItem[];
  lastSyncedAt?: number;
}

