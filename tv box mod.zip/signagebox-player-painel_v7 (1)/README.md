# SignageBox - Digital Signage Android TV (Expo / React Native)

Aplicativo nativo de **Mídia Indoor / Digital Signage** focado em TV Boxes e Android TVs comuns (sem touch), com arquitetura **100% offline-first**, sincronização inteligente de manifesto JSON e controle remoto por heartbeat.

## Como Gerar o Arquivo .APK Direto no Celular / Nuvem

1. Instale o EAS CLI:
   ```bash
   npm install -g eas-cli
   ```

2. Faça Login na conta Expo:
   ```bash
   eas login
   ```

3. Gere o arquivo .APK em 1 comando:
   ```bash
   npx eas-cli build -p android --profile preview
   ```

O terminal gerará um link direto de download e um QR Code para você escanear e baixar o arquivo .APK imediatamente no celular ou TV Box!


## Orientação controlada pelo painel

O manifesto JSON deve incluir `orientation` com um destes valores:

- `"orientation": "landscape"` — horizontal/paisagem.
- `"orientation": "portrait"` — vertical/retrato.

Exemplo mínimo:
```json
{
  "playlistVersion": 13,
  "orientation": "portrait",
  "items": []
}
```

Quando a orientação mudar, o player detecta a diferença mesmo que o painel não incremente `playlistVersion`; ainda assim, recomenda-se incrementar a versão sempre que qualquer configuração do manifesto mudar. Manifestos sem `orientation` continuam usando horizontal como padrão. A orientação física também depende de o firmware da TV Box permitir rotação da tela.
