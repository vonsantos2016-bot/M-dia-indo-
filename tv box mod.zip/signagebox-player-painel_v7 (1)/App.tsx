import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, StatusBar, TouchableOpacity } from 'react-native';
import * as ScreenOrientation from 'expo-screen-orientation';
import { activateKeepAwakeAsync } from 'expo-keep-awake';
import { StorageService } from './src/services/StorageService';
import { SyncService, SyncState } from './src/services/SyncService';
import { SetupScreen } from './src/components/SetupScreen';
import { SignagePlayer } from './src/components/SignagePlayer';

export default function App() {
  const [manifestUrl, setManifestUrl] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const [sync, setSync] = useState<SyncState>(SyncService.getState());
  const playlistState = sync.playlist;

  useEffect(() => {
    activateKeepAwakeAsync().catch((err) => console.warn('[App] Keep-Awake:', err));
  }, []);

  // Estado global da sincronização (playlist somente em memória)
  useEffect(() => SyncService.subscribe(setSync), []);

  // Só o código/URL da tela fica salvo no aparelho — o manifesto não.
  useEffect(() => {
    StorageService.getManifestUrl()
      .then((saved) => { if (saved) setManifestUrl(saved); })
      .catch((err) => console.warn('[App] Erro no bootstrap:', err))
      .finally(() => setIsInitializing(false));
  }, []);

  // Loop de 15 segundos
  useEffect(() => {
    if (!manifestUrl) return;
    SyncService.start(manifestUrl);
    return () => SyncService.stop();
  }, [manifestUrl]);

  useEffect(() => {
    const orientation = playlistState?.orientation === 'portrait' ? 'portrait' : 'landscape';
    ScreenOrientation.lockAsync(
      orientation === 'portrait'
        ? ScreenOrientation.OrientationLock.PORTRAIT
        : ScreenOrientation.OrientationLock.LANDSCAPE
    ).catch((err) => console.warn('[App] Orientação:', err));
  }, [playlistState?.orientation]);

  const handleSaveUrl = async (url: string) => {
    await StorageService.saveManifestUrl(url);
    setManifestUrl(url);
  };

  const handleReconfigure = async () => {
    SyncService.stop();
    await StorageService.clearManifestUrl();
    await StorageService.clearOfflineBackup();
    setManifestUrl(null);
  };

  if (isInitializing) {
    return (
      <View style={styles.splashContainer}>
        <StatusBar hidden={true} />
        <ActivityIndicator size="large" color="#f59e0b" />
        <Text style={styles.splashText}>Inicializando...</Text>
      </View>
    );
  }

  if (!manifestUrl) {
    return (
      <>
        <StatusBar hidden={true} />
        <SetupScreen onSaveUrl={handleSaveUrl} />
      </>
    );
  }

  if (sync.status === 'invalid_screen') {
    return (
      <View style={styles.splashContainer}>
        <StatusBar hidden={true} />
        <Text style={styles.errorTitle}>Código de tela inválido</Text>
        <Text style={styles.splashText}>Confira o código cadastrado no painel. Tentando novamente a cada 15 segundos...</Text>
        <TouchableOpacity hasTVPreferredFocus style={styles.button} onPress={handleReconfigure}>
          <Text style={styles.buttonText}>Trocar código da tela</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!playlistState || playlistState.items.length === 0) {
    return (
      <View style={styles.splashContainer}>
        <StatusBar hidden={true} />
        <ActivityIndicator size="large" color="#f59e0b" />
        <Text style={styles.splashTitle}>
          {sync.status === 'offline' ? 'Aguardando conexão com o painel' : 'Sincronizando Mídia Indoor'}
        </Text>
        <Text style={styles.splashText}>{sync.progressText}</Text>
        <View style={styles.progressBarBg}>
          <View style={[styles.progressBarFill, { width: `${sync.progressPercent}%` }]} />
        </View>
      </View>
    );
  }

  return (
    <View style={styles.fullscreen}>
      <StatusBar hidden={true} />
      <SignagePlayer
        items={playlistState.items}
        playbackMode={playlistState.playbackMode}
        onLoopCompleted={(loop) => console.log(`[App] Loop #${loop}`)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  fullscreen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  splashContainer: {
    flex: 1,
    backgroundColor: '#09090b',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  splashTitle: {
    color: '#ffffff',
    fontSize: 22,
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 8,
  },
  splashText: {
    color: '#a1a1aa',
    fontSize: 14,
    marginBottom: 20,
  },
  progressBarBg: {
    width: 320,
    height: 8,
    backgroundColor: '#27272a',
    borderRadius: 4,
    overflow: 'hidden',
  },
  errorTitle: { color: '#ef4444', fontSize: 28, fontWeight: '800', marginBottom: 12 },
  button: { backgroundColor: '#f59e0b', paddingHorizontal: 24, paddingVertical: 12, borderRadius: 8 },
  buttonText: { color: '#09090b', fontWeight: '700', fontSize: 16 },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#f59e0b',
  },
});