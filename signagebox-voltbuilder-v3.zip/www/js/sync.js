(function (global) {
    'use strict';

    var PANEL_MANIFEST_BASE = 'https://sbbsivqsxculsmjbiaid.supabase.co/functions/v1/manifest/screens';
    var SYNC_INTERVAL_MS = 15000;
    var REQUEST_TIMEOUT_MS = 10000;

    function buildManifestUrl(screenCodeOrUrl) {
        var v = String(screenCodeOrUrl || '').trim();
        if (/^https?:\/\//i.test(v)) return v;
        return PANEL_MANIFEST_BASE + '/' + encodeURIComponent(v) + '/manifest.json';
    }

    var state = {
        status: 'idle',
        playlist: null,
        progressText: '',
        progressPercent: 0,
        lastHttpStatus: null
    };

    var listeners = [];
    var loopTimer = null;
    var loopUrl = null;
    var running = false;
    var inFlight = false;

    function setState(patch) {
        Object.keys(patch).forEach(function (k) {
            state[k] = patch[k];
        });
        listeners.forEach(function (fn) {
            try { fn(state); } catch (e) {}
        });
    }

    function generateLocalFilename(item) {
        var sanitizedId = String(item.id || 'item').replace(/[^a-zA-Z0-9_-]/g, '_');
        var path = String(item.url || '').split('?')[0];
        var extCandidate = path.indexOf('.') !== -1 ? path.split('.').pop().toLowerCase() : null;
        var defaultExt = item.type === 'video' ? 'mp4' : 'jpg';
        var allowed = ['mp4', 'mkv', 'webm', 'mov', 'jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'];
        var ext = (extCandidate && allowed.indexOf(extCandidate) !== -1) ? extCandidate : defaultExt;
        return 'media_' + sanitizedId + '.' + ext;
    }

    function fetchRemoteManifest(manifestUrl) {
        var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
        var timeoutId = setTimeout(function () {
            if (controller) controller.abort();
        }, REQUEST_TIMEOUT_MS);

        var sep = manifestUrl.indexOf('?') !== -1 ? '&' : '?';
        var urlWithBust = manifestUrl + sep + '_t=' + Date.now();

        return fetch(urlWithBust, {
            signal: controller ? controller.signal : undefined,
            headers: {
                'Accept': 'application/json',
                'Cache-Control': 'no-cache'
            }
        }).then(function (response) {
            if (response.status !== 200) {
                var err = new Error('HTTP ' + response.status);
                err.httpStatus = response.status;
                throw err;
            }
            return response.json();
        }).then(function (data) {
            if (!data || typeof data.playlistVersion !== 'number' || !Array.isArray(data.items)) {
                throw new Error('Manifesto malformado');
            }
            data.items = data.items
                .filter(function (raw) { return raw && typeof raw === 'object'; })
                .map(function (raw, i) {
                    var dur = Math.max(1, Number(raw.duration || raw.duration_seconds) || 0) || undefined;
                    return Object.assign({}, raw, {
                        id: String(raw.id !== undefined ? raw.id : 'item-' + i),
                        url: raw.url || raw.source_url || '',
                        title: raw.title || '',
                        duration: dur
                    });
                })
                .filter(function (it) { return !!it.url; });
            return data;
        }).finally(function () {
            clearTimeout(timeoutId);
        });
    }

    function downloadMedia(manifest, manifestUrl) {
        var total = manifest.items.length;
        var resolvedItems = [];
        setState({
            progressText: 'Baixando nova versão (' + manifest.playlistVersion + ')...',
            progressPercent: 10
        });

        var chain = Promise.resolve();

        manifest.items.forEach(function (item, i) {
            chain = chain.then(function () {
                if (global.DynamicService.isDynamicType(item.type)) {
                    resolvedItems.push(Object.assign({}, item, { localUri: '', filename: '' }));
                    return;
                }
                if (item.type !== 'video' && item.type !== 'image') {
                    return;
                }

                var filename = generateLocalFilename(item);
                var pct = 10 + Math.floor((i / Math.max(1, total)) * 80);
                setState({
                    progressText: 'Baixando mídia ' + (i + 1) + '/' + total + ': ' + (item.title || item.id),
                    progressPercent: pct
                });

                return global.StorageService.fileExists(filename).then(function (existingEntry) {
                    if (existingEntry) {
                        var existingUri = global.StorageService.resolvePlayableUrlFromEntry(existingEntry);
                        resolvedItems.push(Object.assign({}, item, {
                            localUri: existingUri,
                            filename: filename,
                            downloadedAt: Date.now()
                        }));
                        return;
                    }

                    return global.StorageService.downloadAndSaveMedia(item.url, filename)
                        .then(function (saved) {
                            resolvedItems.push(Object.assign({}, item, {
                                localUri: saved.localUri,
                                filename: filename,
                                downloadedAt: Date.now()
                            }));
                        })
                        .catch(function () {
                            // Fallback: usa a própria URL remota se o download local falhar
                            resolvedItems.push(Object.assign({}, item, {
                                localUri: item.url,
                                filename: '',
                                downloadedAt: Date.now()
                            }));
                        });
                });
            });
        });

        return chain.then(function () {
            var activeFilenames = resolvedItems.map(function (it) { return it.filename; }).filter(Boolean);
            return global.StorageService.cleanupObsoleteMedia(activeFilenames).then(function () {
                setState({ progressText: 'Sincronização concluída!', progressPercent: 100 });
                return {
                    playlistVersion: manifest.playlistVersion,
                    orientation: manifest.orientation === 'portrait' ? 'portrait' : 'landscape',
                    playbackMode: manifest.playbackMode === 'random' ? 'random' : 'sequential',
                    manifestUrl: manifestUrl,
                    items: resolvedItems,
                    lastSyncedAt: Date.now()
                };
            });
        });
    }

    function restoreBackupIfOffline() {
        var backup = global.StorageService.getOfflineBackup();
        if (!backup || !Array.isArray(backup.items) || backup.manifestUrl !== loopUrl) {
            return Promise.resolve();
        }
        var validItems = [];
        var chain = Promise.resolve();

        backup.items.forEach(function (it) {
            chain = chain.then(function () {
                if (!it.filename) {
                    validItems.push(it);
                    return;
                }
                return global.StorageService.fileExists(it.filename).then(function (entry) {
                    if (entry) {
                        validItems.push(Object.assign({}, it, {
                            localUri: global.StorageService.resolvePlayableUrlFromEntry(entry)
                        }));
                    }
                });
            });
        });

        return chain.then(function () {
            if (validItems.length > 0) {
                setState({
                    playlist: Object.assign({}, backup, { items: validItems }),
                    status: 'ok'
                });
            }
        });
    }

    function runCycle() {
        if (inFlight || !loopUrl) return Promise.resolve();
        inFlight = true;

        return fetchRemoteManifest(loopUrl).then(function (manifest) {
            setState({ lastHttpStatus: 200 });

            if (manifest.remoteCommand === 'QUIT_PLAYER') {
                stop();
                if (navigator.app && typeof navigator.app.exitApp === 'function') {
                    setTimeout(function () { navigator.app.exitApp(); }, 300);
                }
                return;
            }

            var current = state.playlist;
            var orientation = manifest.orientation === 'portrait' ? 'portrait' : 'landscape';
            var playbackMode = manifest.playbackMode === 'random' ? 'random' : 'sequential';

            var changed = !current ||
                manifest.playlistVersion !== current.playlistVersion ||
                orientation !== (current.orientation || 'landscape') ||
                playbackMode !== (current.playbackMode || 'sequential');

            if (!changed) {
                if (state.status !== 'ok') setState({ status: 'ok' });
                return;
            }

            return downloadMedia(manifest, loopUrl).then(function (playlist) {
                setState({ status: 'ok', playlist: playlist });
                global.StorageService.saveOfflineBackup(playlist);
            });
        }).catch(function (err) {
            if (err && err.httpStatus === 404) {
                setState({ status: 'invalid_screen', lastHttpStatus: 404, playlist: null });
                global.StorageService.clearOfflineBackup();
            } else {
                setState({
                    status: state.playlist ? 'ok' : 'offline',
                    lastHttpStatus: (err && err.httpStatus) ? err.httpStatus : null
                });
            }
        }).finally(function () {
            inFlight = false;
        });
    }

    function start(screenCodeOrUrl) {
        stop();
        loopUrl = buildManifestUrl(screenCodeOrUrl);
        running = true;

        function tick() {
            var prep = !state.playlist ? restoreBackupIfOffline() : Promise.resolve();
            prep.then(function () {
                if (!running) return;
                var startedAt = Date.now();
                return runCycle().then(function () {
                    if (!running) return;
                    var wait = Math.max(0, SYNC_INTERVAL_MS - (Date.now() - startedAt));
                    loopTimer = setTimeout(tick, wait);
                });
            });
        }

        tick();
    }

    function stop() {
        running = false;
        if (loopTimer) clearTimeout(loopTimer);
        loopTimer = null;
    }

    global.SyncService = {
        buildManifestUrl: buildManifestUrl,
        getState: function () { return state; },
        subscribe: function (listener) {
            listeners.push(listener);
            listener(state);
            return function () {
                var idx = listeners.indexOf(listener);
                if (idx !== -1) listeners.splice(idx, 1);
            };
        },
        start: start,
        stop: stop
    };
})(window);
