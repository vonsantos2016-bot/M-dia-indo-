(function (global) {
    'use strict';

    var sourceItems = [];
    var queue = [];
    var currentIndex = 0;
    var playbackMode = 'sequential';
    var timerId = null;
    var watchdogId = null;
    var activeSignature = '';

    function shuffle(arr) {
        var q = arr.slice();
        for (var i = q.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var tmp = q[i];
            q[i] = q[j];
            q[j] = tmp;
        }
        return q;
    }

    function processQueue(items, mode) {
        return mode === 'random' ? shuffle(items) : items.slice();
    }

    function clearTimers() {
        if (timerId) {
            clearTimeout(timerId);
            timerId = null;
        }
        if (watchdogId) {
            clearTimeout(watchdogId);
            watchdogId = null;
        }
    }

    function advanceToNext() {
        clearTimers();
        if (!queue.length) return;

        currentIndex = (currentIndex + 1) % queue.length;
        if (currentIndex === 0 && playbackMode === 'random') {
            queue = processQueue(sourceItems, playbackMode);
        }
        renderCurrentItem();
    }

    function renderCurrentItem() {
        clearTimers();
        var stage = document.getElementById('media-stage');
        if (!stage) return;

        var item = queue[currentIndex];
        if (!item) {
            stage.innerHTML = '';
            return;
        }

        if (global.DynamicService.isDynamicType(item.type)) {
            stage.innerHTML = global.DynamicService.renderDynamicHtml(item, null);
            var renderedItemId = item.id;
            var renderedIdx = currentIndex;

            global.DynamicService.fetchDynamicContent(item).then(function (res) {
                if (queue[currentIndex] && queue[currentIndex].id === renderedItemId && currentIndex === renderedIdx) {
                    stage.innerHTML = global.DynamicService.renderDynamicHtml(item, res);
                }
            });

            var dynDuration = (item.duration && item.duration > 0) ? item.duration : 10;
            timerId = setTimeout(advanceToNext, dynDuration * 1000);
            return;
        }

        if (item.type === 'video') {
            stage.innerHTML = '';
            var video = document.createElement('video');
            video.className = 'fullscreen-media';
            video.src = item.localUri;
            video.autoplay = true;
            video.playsInline = true;
            video.muted = false;
            video.loop = false;

            video.onended = function () {
                advanceToNext();
            };
            video.onerror = function () {
                advanceToNext();
            };

            stage.appendChild(video);

            var playPromise = video.play();
            if (playPromise && typeof playPromise.catch === 'function') {
                playPromise.catch(function () {
                    // Em TVs/WebViews que exigem mute no autoplay
                    video.muted = true;
                    video.play().catch(function () {
                        advanceToNext();
                    });
                });
            }

            var maxTimeout = ((item.duration && item.duration > 0) ? (item.duration + 5) : 45) * 1000;
            watchdogId = setTimeout(advanceToNext, maxTimeout);
            return;
        }

        // Imagem estática
        stage.innerHTML = '';
        var img = document.createElement('img');
        img.className = 'fullscreen-media';
        img.src = item.localUri;
        img.onerror = function () {
            advanceToNext();
        };
        stage.appendChild(img);

        var imgDuration = (item.duration && item.duration > 0) ? item.duration : 10;
        timerId = setTimeout(advanceToNext, imgDuration * 1000);
    }

    function setPlaylist(items, mode, signature) {
        if (signature && signature === activeSignature && queue.length > 0) {
            return;
        }
        activeSignature = signature || '';
        sourceItems = items || [];
        playbackMode = mode === 'random' ? 'random' : 'sequential';
        queue = processQueue(sourceItems, playbackMode);
        currentIndex = 0;
        renderCurrentItem();
    }

    function stop() {
        clearTimers();
        activeSignature = '';
        sourceItems = [];
        queue = [];
        var stage = document.getElementById('media-stage');
        if (stage) stage.innerHTML = '';
    }

    global.SignagePlayer = {
        setPlaylist: setPlaylist,
        stop: stop
    };
})(window);
