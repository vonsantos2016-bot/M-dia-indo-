(function (global) {
    'use strict';

    var KEY_MANIFEST_URL = '@signage_manifest_url';
    var KEY_BACKUP = '@signage_offline_backup';
    var CACHE_PREFIX = '@signage_dynamic_cache:';
    var MEDIA_FOLDER_NAME = 'signage_media';

    function getDataDirectoryEntry() {
        return new Promise(function (resolve, reject) {
            if (!global.cordova || !global.cordova.file || !global.resolveLocalFileSystemURL) {
                return reject(new Error('Cordova File plugin indisponível'));
            }
            var baseDir = global.cordova.file.dataDirectory || global.cordova.file.externalDataDirectory;
            global.resolveLocalFileSystemURL(baseDir, resolve, reject);
        });
    }

    function ensureMediaDirectory() {
        return getDataDirectoryEntry().then(function (rootDir) {
            return new Promise(function (resolve, reject) {
                rootDir.getDirectory(MEDIA_FOLDER_NAME, { create: true, exclusive: false }, resolve, reject);
            });
        });
    }

    function fileExists(filename) {
        return ensureMediaDirectory().then(function (dirEntry) {
            return new Promise(function (resolve) {
                dirEntry.getFile(filename, { create: false }, function (fileEntry) {
                    resolve(fileEntry);
                }, function () {
                    resolve(null);
                });
            });
        }).catch(function () {
            return null;
        });
    }

    function downloadAndSaveMedia(url, filename) {
        return fetch(url, { cache: 'no-store' }).then(function (response) {
            if (!response.ok) {
                throw new Error('HTTP ' + response.status);
            }
            return response.blob();
        }).then(function (blob) {
            return ensureMediaDirectory().then(function (dirEntry) {
                return new Promise(function (resolve, reject) {
                    dirEntry.getFile(filename, { create: true, exclusive: false }, function (fileEntry) {
                        fileEntry.createWriter(function (writer) {
                            writer.onwriteend = function () {
                                var playableUrl = typeof fileEntry.toURL === 'function' ? fileEntry.toURL() : fileEntry.nativeURL;
                                if (global.Ionic && global.Ionic.WebView && typeof global.Ionic.WebView.convertFileSrc === 'function') {
                                    playableUrl = global.Ionic.WebView.convertFileSrc(playableUrl);
                                } else if (global.WkWebView && typeof global.WkWebView.convertFilePath === 'function') {
                                    playableUrl = global.WkWebView.convertFilePath(playableUrl);
                                }
                                resolve({ filename: filename, localUri: playableUrl });
                            };
                            writer.onerror = function (err) {
                                reject(err);
                            };
                            writer.write(blob);
                        }, reject);
                    }, reject);
                });
            });
        });
    }

    function resolvePlayableUrlFromEntry(fileEntry) {
        var playableUrl = typeof fileEntry.toURL === 'function' ? fileEntry.toURL() : fileEntry.nativeURL;
        if (global.Ionic && global.Ionic.WebView && typeof global.Ionic.WebView.convertFileSrc === 'function') {
            playableUrl = global.Ionic.WebView.convertFileSrc(playableUrl);
        }
        return playableUrl;
    }

    function cleanupObsoleteMedia(activeFilenames) {
        return ensureMediaDirectory().then(function (dirEntry) {
            return new Promise(function (resolve) {
                var reader = dirEntry.createReader();
                reader.readEntries(function (entries) {
                    var tasks = entries.map(function (entry) {
                        if (entry.isFile && activeFilenames.indexOf(entry.name) === -1) {
                            return new Promise(function (res) {
                                entry.remove(res, res);
                            });
                        }
                        return Promise.resolve();
                    });
                    Promise.all(tasks).then(resolve);
                }, function () {
                    resolve();
                });
            });
        }).catch(function () {});
    }

    global.StorageService = {
        saveManifestUrl: function (url) {
            localStorage.setItem(KEY_MANIFEST_URL, String(url || '').trim());
        },
        getManifestUrl: function () {
            return localStorage.getItem(KEY_MANIFEST_URL);
        },
        clearManifestUrl: function () {
            localStorage.removeItem(KEY_MANIFEST_URL);
        },
        saveOfflineBackup: function (state) {
            try {
                localStorage.setItem(KEY_BACKUP, JSON.stringify(state));
            } catch (e) {}
        },
        getOfflineBackup: function () {
            try {
                var raw = localStorage.getItem(KEY_BACKUP);
                return raw ? JSON.parse(raw) : null;
            } catch (e) {
                return null;
            }
        },
        clearOfflineBackup: function () {
            try {
                localStorage.removeItem(KEY_BACKUP);
            } catch (e) {}
        },
        saveDynamicCache: function (id, payload) {
            try {
                localStorage.setItem(CACHE_PREFIX + id, JSON.stringify(payload));
            } catch (e) {}
        },
        getDynamicCache: function (id) {
            try {
                var raw = localStorage.getItem(CACHE_PREFIX + id);
                return raw ? JSON.parse(raw) : null;
            } catch (e) {
                return null;
            }
        },
        fileExists: fileExists,
        resolvePlayableUrlFromEntry: resolvePlayableUrlFromEntry,
        downloadAndSaveMedia: downloadAndSaveMedia,
        cleanupObsoleteMedia: cleanupObsoleteMedia
    };
})(window);
