(function (global) {
    'use strict';

    var currentManifestUrl = null;
    var currentOrientation = null;

    function showScreen(screenId) {
        var screens = document.querySelectorAll('.screen');
        screens.forEach(function (el) {
            if (el.id === screenId) {
                el.classList.add('active');
            } else {
                el.classList.remove('active');
            }
        });
    }

    function applyOrientation(orientation) {
        var target = orientation === 'portrait' ? 'portrait' : 'landscape';
        if (currentOrientation === target) return;
        currentOrientation = target;

        try {
            if (global.screen && global.screen.orientation && typeof global.screen.orientation.lock === 'function') {
                global.screen.orientation.lock(target).catch(function () {});
            }
        } catch (e) {}
    }

    function keepAwake() {
        try {
            if (navigator.wakeLock && typeof navigator.wakeLock.request === 'function') {
                navigator.wakeLock.request('screen').catch(function () {});
            }
        } catch (e) {}
    }

    function renderAppState(syncState) {
        if (!currentManifestUrl) {
            global.SignagePlayer.stop();
            showScreen('screen-setup');
            var inputEl = document.getElementById('input-screen-code');
            if (inputEl) setTimeout(function () { inputEl.focus(); }, 100);
            return;
        }

        if (syncState.status === 'invalid_screen') {
            global.SignagePlayer.stop();
            showScreen('screen-invalid');
            var btnReconfig = document.getElementById('btn-reconfigure');
            if (btnReconfig) setTimeout(function () { btnReconfig.focus(); }, 100);
            return;
        }

        var playlist = syncState.playlist;
        if (!playlist || !playlist.items || playlist.items.length === 0) {
            global.SignagePlayer.stop();
            showScreen('screen-splash');
            var titleEl = document.getElementById('splash-title');
            var textEl = document.getElementById('splash-text');
            var progWrap = document.getElementById('progress-wrapper');
            var progFill = document.getElementById('progress-fill');

            if (titleEl) {
                titleEl.textContent = syncState.status === 'offline'
                    ? 'Aguardando conexão com o painel'
                    : 'Sincronizando Mídia Indoor';
            }
            if (textEl) {
                textEl.textContent = syncState.progressText || 'Conectando ao servidor...';
            }
            if (progWrap && progFill) {
                progWrap.classList.remove('hidden');
                progFill.style.width = (syncState.progressPercent || 0) + '%';
            }
            return;
        }

        applyOrientation(playlist.orientation);
        showScreen('screen-player');

        var signature = playlist.playlistVersion + ':' + (playlist.orientation || 'landscape') + ':' + (playlist.playbackMode || 'sequential');
        global.SignagePlayer.setPlaylist(playlist.items, playlist.playbackMode, signature);
    }

    function bindUiEvents() {
        var inputEl = document.getElementById('input-screen-code');
        var btnConnect = document.getElementById('btn-connect');
        var errEl = document.getElementById('setup-error');
        var btnReconfigure = document.getElementById('btn-reconfigure');

        function handleConnect() {
            var raw = inputEl ? inputEl.value.trim() : '';
            if (!raw) {
                if (errEl) {
                    errEl.textContent = 'Digite o ID da tela cadastrada no painel.';
                    errEl.classList.remove('hidden');
                }
                return;
            }
            if (errEl) errEl.classList.add('hidden');

            var fullUrl = global.SyncService.buildManifestUrl(raw);
            global.StorageService.saveManifestUrl(fullUrl);
            currentManifestUrl = fullUrl;
            global.SyncService.start(fullUrl);
        }

        if (btnConnect) {
            btnConnect.addEventListener('click', handleConnect);
        }

        if (inputEl) {
            inputEl.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' || e.keyCode === 13) {
                    e.preventDefault();
                    handleConnect();
                }
            });
        }

        if (btnReconfigure) {
            btnReconfigure.addEventListener('click', function () {
                global.SyncService.stop();
                global.StorageService.clearManifestUrl();
                global.StorageService.clearOfflineBackup();
                currentManifestUrl = null;
                renderAppState(global.SyncService.getState());
            });
        }
    }

    function bootstrap() {
        keepAwake();
        bindUiEvents();

        global.SyncService.subscribe(function (syncState) {
            renderAppState(syncState);
        });

        var savedUrl = global.StorageService.getManifestUrl();
        if (savedUrl) {
            currentManifestUrl = savedUrl;
            global.SyncService.start(savedUrl);
        } else {
            renderAppState(global.SyncService.getState());
        }
    }

    if (global.cordova) {
        document.addEventListener('deviceready', bootstrap, false);
    } else {
        window.addEventListener('DOMContentLoaded', bootstrap);
    }
})(window);
