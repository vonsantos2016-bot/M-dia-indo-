(function (global) {
    'use strict';

    var DYNAMIC_TYPES = ['rss_feed', 'weather_api', 'lottery_json'];

    function escapeHtml(str) {
        return String(str || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function decodeXmlEntities(s) {
        return String(s || '')
            .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
            .replace(/<[^>]+>/g, '')
            .replace(/&amp;/g, '&')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&quot;/g, '"')
            .replace(/&#39;|&apos;/g, "'")
            .trim();
    }

    function parseRss(xml) {
        var text = String(xml || '');
        var channelMatch = text.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
        var channel = decodeXmlEntities(channelMatch ? channelMatch[1] : 'Notícias');
        var blocks = text.match(/<(item|entry)[\s>][\s\S]*?<\/>/gi) || [];
        var titles = blocks.map(function (b) {
            var m = b.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
            return decodeXmlEntities(m ? m[1] : '');
        }).filter(Boolean);
        return { channel: channel, titles: titles };
    }

    function fetchDynamicContent(item) {
        var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
        var timer = setTimeout(function () {
            if (controller) controller.abort();
        }, 10000);

        return fetch(item.url, {
            signal: controller ? controller.signal : undefined,
            headers: { 'Cache-Control': 'no-cache' }
        }).then(function (res) {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return item.type === 'rss_feed' ? res.text() : res.json();
        }).then(function (content) {
            var payload = { content: content, fetchedAt: new Date().toISOString() };
            global.StorageService.saveDynamicCache(item.id, payload);
            return { content: payload.content, fetchedAt: payload.fetchedAt, fromCache: false };
        }).catch(function () {
            var cached = global.StorageService.getDynamicCache(item.id);
            if (cached) {
                return { content: cached.content, fetchedAt: cached.fetchedAt, fromCache: true };
            }
            return null;
        }).finally(function () {
            clearTimeout(timer);
        });
    }

    function renderFooter(timestamp, fromCache) {
        if (!timestamp) return '';
        var formatted = new Date(timestamp).toLocaleString('pt-BR');
        return '<div class="updated-footer">' + (fromCache ? 'Modo offline · ' : '') + 'Atualizado em: ' + escapeHtml(formatted) + '</div>';
    }

    function renderDynamicHtml(item, result) {
        if (!result) {
            return '<div class="dynamic-wrapper"><div class="spinner"></div></div>';
        }

        if (item.type === 'weather_api') {
            var r = (result.content && result.content.results) ? result.content.results : (result.content || {});
            var city = r.city || r.city_name || r.name || '';
            var temp = (r.temp !== undefined ? r.temp : (r.temperature !== undefined ? r.temperature : (r.main && r.main.temp !== undefined ? r.main.temp : '--')));
            var desc = r.description || (r.weather && r.weather[0] && r.weather[0].description) || '';
            return (
                '<div class="dynamic-wrapper">' +
                    '<div class="card-weather">' +
                        '<div class="weather-title">Previsão do Tempo</div>' +
                        '<div class="weather-city">' + escapeHtml(city) + '</div>' +
                        '<div class="weather-temp">' + escapeHtml(temp) + '°C</div>' +
                        '<div class="weather-desc">' + escapeHtml(desc) + '</div>' +
                        renderFooter(result.fetchedAt, result.fromCache) +
                    '</div>' +
                '</div>'
            );
        }

        if (item.type === 'rss_feed') {
            var parsed = parseRss(result.content);
            var maxItems = item.maxItems || 5;
            var listHtml = parsed.titles.slice(0, maxItems).map(function (t) {
                return '<div class="rss-item">• ' + escapeHtml(t) + '</div>';
            }).join('');
            if (!listHtml) {
                listHtml = '<div class="rss-item">Nenhuma notícia disponível.</div>';
            }
            return (
                '<div class="dynamic-wrapper">' +
                    '<div class="card-rss">' +
                        '<div class="rss-channel">' + escapeHtml(parsed.channel) + '</div>' +
                        listHtml +
                        renderFooter(result.fetchedAt, result.fromCache) +
                    '</div>' +
                '</div>'
            );
        }

        if (item.type === 'lottery_json') {
            var d = Array.isArray(result.content) ? result.content[0] : (result.content || {});
            var rawDezenas = d.dezenas || d.listaDezenas || d.dezenasSorteadasOrdemSorteio || [];
            var concurso = d.concurso || d.numero || '';
            var data = d.data || d.dataApuracao || '';
            var acumulou = d.acumulou !== undefined ? d.acumulou : d.acumulado;
            var proximo = d.valorEstimadoProximoConcurso;

            var ballsHtml = rawDezenas.map(function (n) {
                var padded = String(n).padStart(2, '0');
                return '<div class="mega-ball">' + escapeHtml(padded) + '</div>';
            }).join('');

            var accHtml = acumulou !== undefined
                ? '<div class="mega-acc">' + (acumulou ? 'ACUMULOU!' : 'Teve ganhador') + '</div>'
                : '';

            var nextHtml = typeof proximo === 'number'
                ? '<div class="mega-sub">Próximo prêmio estimado: ' + escapeHtml(proximo.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })) + '</div>'
                : '';

            return (
                '<div class="dynamic-wrapper">' +
                    '<div class="card-megasena">' +
                        '<div class="mega-title">MEGA-SENA</div>' +
                        '<div class="mega-sub">Concurso ' + escapeHtml(concurso) + (data ? ' · ' + escapeHtml(data) : '') + '</div>' +
                        '<div class="mega-balls">' + ballsHtml + '</div>' +
                        accHtml +
                        nextHtml +
                        renderFooter(result.fetchedAt, result.fromCache) +
                    '</div>' +
                '</div>'
            );
        }

        return '<div class="dynamic-wrapper"></div>';
    }

    global.DynamicService = {
        DYNAMIC_TYPES: DYNAMIC_TYPES,
        isDynamicType: function (type) {
            return DYNAMIC_TYPES.indexOf(type) !== -1;
        },
        fetchDynamicContent: fetchDynamicContent,
        renderDynamicHtml: renderDynamicHtml
    };
})(window);
